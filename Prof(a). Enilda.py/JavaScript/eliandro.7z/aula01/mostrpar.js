// Mostrar os números pares entre 2 a 50
console.log("Números pares entre 2 e 50:");

for (let i = 2; i <= 50; i += 2) {
  console.log(i); // Exibe o número par
}

// Esse código imprimirá todos os números pares entre 2 e 50. Se você quiser exibir os números em uma matriz, você pode fazer assim:

// Javascript-escritor

// Copiar código
let numerosPares = [];

for (let i = 2; i <= 50; i += 2) {
  numerosPares.push(i); // Adiciona o número par ao array
}

console.log("Números pares entre 2 e 50:", numerosPares);
// Nesse segundo exemplo, os números pares são armazenados em um array chamado numerosParese, em seguida, são exibidos no console.