console.log('Olá Mundo');
// alert('Será?')

var soma = 15; 
var _soma = 15; 
let $numero = 10;
let $Numero = 20
let numero = 10;
let Numero = 15; 
let numeroDois = 15; 
const pi = 3.14;

resultado = numero + Numero - pi;
console.log(resultado)