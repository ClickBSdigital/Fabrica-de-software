for (let i = 11; i <= 101; i += 10) {
    console.log(i);
  }
  